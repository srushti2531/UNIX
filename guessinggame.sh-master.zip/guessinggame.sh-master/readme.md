Guessing Game with number of lines:
24
Wed 13 Sep 01:54:43 AEST 2017
